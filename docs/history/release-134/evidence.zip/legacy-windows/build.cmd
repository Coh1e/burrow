@echo off
setlocal
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
set "PATH=<checkout>\.local\issue120-tools\w64devkit\bin;%PATH%"
set "TEMP=<checkout>\.local\tmp"
set "TMP=%TEMP%"
cmake -S . -B .local/131-legacy-build -G Ninja -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 exit /b 1
cmake --build .local/131-legacy-build --parallel 4
if errorlevel 1 exit /b 1
ctest --test-dir .local/131-legacy-build --parallel 4 --no-tests=error --output-on-failure
exit /b %errorlevel%