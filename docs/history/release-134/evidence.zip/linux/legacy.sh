#!/bin/sh
# Run with unshare --mount --net --propagation private as root in the WSL host.
set -eu
rev=${1:?revision} src=${2:?source checkout} root=${3:?preprovisioned Trusty root}
export PATH=/usr/local/bin:/usr/bin:/bin LC_ALL=C
test "$(git -c safe.directory="$src" -C "$src" rev-parse HEAD)" = "$rev"
test "$(git -c safe.directory="$src" -C "$src" diff "$rev" -- brw scripts/check-brw-legacy.sh)" = ""
printf 'revision=%s\nbrw_tree=%s\n' "$rev" "$(git -c safe.directory="$src" -C "$src" rev-parse HEAD:brw)"
uname -srm
mount --bind "$src" "$root/work/src"
mount -o remount,bind,ro "$root/work/src"
mount -t tmpfs -o size=1G tmpfs "$root/work/src/.local/legacy-build"
mount -t tmpfs -o size=64M tmpfs "$root/tmp"
mount --rbind /proc "$root/proc"
for dev in null zero random urandom; do mount --bind "/dev/$dev" "$root/dev/$dev"; done
findmnt --noheadings --output OPTIONS --target "$root/work/src"
findmnt --noheadings --output FSTYPE,OPTIONS --target "$root/work/src/.local/legacy-build"
printf 'network namespace '; readlink /proc/self/ns/net
ip -o link show
printf 'IPv4 routes (all tables)\n'; ip -4 route show table all
printf 'IPv6 routes (all tables)\n'; ip -6 route show table all
chroot "$root" /bin/sh -ec 'PATH=/opt/cmake-3.10.3-Linux-x86_64/bin:/usr/bin:/bin; export PATH; cd /work/src; exec sh -x scripts/check-brw-legacy.sh'
