#!/bin/sh
# Run as the ordinary WSL user. CHECKOUT already contains the pinned source archives.
set -eu
rev=${1:?revision} checkout=${2:?checkout} stage=${3:?empty work directory}
export PATH=/usr/local/bin:/usr/bin:/bin LC_ALL=C.UTF-8
git -c safe.directory="$checkout" clone --quiet --shared --no-checkout "$checkout" "$stage/source"
git -C "$stage/source" checkout --quiet --detach "$rev"
cd "$stage/source"
test "$(git rev-parse HEAD)" = "$rev"
test -z "$(git status --porcelain)"
printf 'revision=%s\nbrw_tree=%s\n' "$(git rev-parse HEAD)" "$(git rev-parse HEAD:brw)"
mkdir -p .local/deps/sources .local/legacy-build
while read -r file digest url; do
    cp "$checkout/.local/deps/sources/$file" ".local/deps/sources/$file"
    printf '%s  %s\n' "$digest" ".local/deps/sources/$file" | sha256sum -c -
done < scripts/blueprint-sources.txt
sh scripts/fetch-blueprint-deps.sh
