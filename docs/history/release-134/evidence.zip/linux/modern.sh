#!/bin/sh
# Run as the ordinary WSL user, supplying a fresh 9p work directory for the case-metadata test.
set -eux
rev=${1:?revision} src=${2:?source checkout} evidence=${3:?evidence directory} case9p=${4:?new 9p directory}
export PATH=/usr/local/bin:/usr/bin:/bin LC_ALL=C.UTF-8 GIT_CONFIG_NOSYSTEM=1
cd "$src"
test "$(git rev-parse HEAD)" = "$rev"
test -z "$(git status --porcelain)"
git rev-parse HEAD HEAD:brw
cat /etc/os-release
uname -srm
gcc --version
g++ --version
cmake --version
make --version
python3 --version
sha256sum tests/blueprint-acceptance/kit/blueprint.manifest
build="$src/.local/c"
CC=gcc CXX=/nonexistent/brw-cxx cmake -S brw -B "$build" -G 'Unix Makefiles' \
    -DCMAKE_BUILD_TYPE=Release -DBRW_BLUEPRINT=ON -DBUILD_TESTING=ON -DBRW_TEST_GIT=ON \
    -DBRW_ENABLE_CPP_MODULE=OFF
if grep -q '^CMAKE_CXX_COMPILER:' "$build/CMakeCache.txt"; then exit 1; fi
cmake --build "$build" --parallel 6
sha256sum "$build/brw"
ctest --test-dir "$build" --no-tests=error --output-on-failure
ctest --test-dir "$build" --no-tests=error --output-on-failure -V -R '^blueprint_cli_ramfs$'
mkdir "$case9p"
(
    cd "$case9p"
    test "$(stat -f -c %t .)" = 1021997
    sh "$src/brw/blueprint_unknown_case_test.sh" cmake "-DBRW=$build/brw" -DBLUEPRINT_UNKNOWN_CASE_ONLY=ON -P "$src/brw/blueprint_test.cmake"
)
printf '9p case-metadata scenario completed with exit 0\n'
python3 -B tests/blueprint-acceptance/run.py --build-dir "$build" --evidence "$evidence/blueprint"
cpp="$src/.local/cpp"
CC=gcc CXX=g++ cmake -S brw -B "$cpp" -G 'Unix Makefiles' -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_TESTING=ON -DBRW_BLUEPRINT=OFF -DBRW_ENABLE_CPP_MODULE=ON
cmake --build "$cpp" --parallel 4
ctest --test-dir "$cpp" --no-tests=error --output-on-failure
san="$src/.local/san"
CC=gcc CXX=g++ cmake -S brw -B "$san" -G 'Unix Makefiles' -DCMAKE_BUILD_TYPE=Debug \
    -DBUILD_TESTING=ON -DBRW_BLUEPRINT=OFF -DBRW_ENABLE_CPP_MODULE=ON \
    -DCMAKE_C_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
    -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer'
cmake --build "$san" --parallel 4
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 \
    ctest --test-dir "$san" --no-tests=error --output-on-failure
test -z "$(git status --porcelain)"
