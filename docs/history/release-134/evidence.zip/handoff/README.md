# #134 候选人工验收

候选提交 `5e34c7819fadeea2a0eb373231e50941161b910c`。Windows 交付 ZIP 的 SHA-256 为 `d5ddcd95ae06c7609d35f13f96aa3edb9d883015eaaa2f1968c2316325724c77`，解压后 `brw.exe` 的 SHA-256 为 `49328dce03efe66a953462536c1698debab21caefd7fc55370bf2456d7673ba3`。独立核验时可与仓库的候选验收报告对照。`checksums.json` 给出包内各文件的字节数和摘要。

## 干净 Windows 11 x64 构建机

使用独立新镜像，预置 Git、Python 3.12+ 和本交接包。将虚拟机网卡断开，从交接包根目录在 PowerShell 中执行。记录镜像来源、Windows 版本、构建退出码。驱动在解包源码前后验证断网，独立解压已固定的 SDK 和依赖，为每个生成器创建新目录。

~~~powershell
git clone --no-checkout .\candidate.bundle .\candidate
git -C .\candidate switch --detach 5e34c7819fadeea2a0eb373231e50941161b910c
New-Item -ItemType Directory -Force .\candidate\.local\deps\sources | Out-Null
Copy-Item .\sources\* .\candidate\.local\deps\sources\
Set-Location .\candidate
python -B tests/release-acceptance/windows_build.py --revision 5e34c7819fadeea2a0eb373231e50941161b910c --devkit-archive ..\tools\w64devkit-x64-2.11.0.7z.exe --work .local\build-134 --jobs 4
~~~

返回 `.local/build-134/evidence/`。核对两种生成器都能构建、启动，网络探针前后通过，体积及 DLL 均过门槛。把该次生成的 `brw-windows-x64.zip` 复制到后一节的干净运行机。使用新构建时，将后一节命令的两个 SHA-256 分别换为此次 `windows-build.json` 中 `delivery.download.sha256` 和 `delivery.files["brw.exe"].sha256`。验证本次已打包的候选交付件时直接使用后一节原命令。

## 无开发工具的干净 Windows 11 x64

在新配置、无开发工具的 Windows 11 x64 上解压本交接包。记录镜像来源、版本和安装软件情况。使用系统自带的 **64 位 Windows PowerShell 5.1**，从交接包根目录运行；把镜像说明换成真实值。

```powershell
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File .\clean-windows.ps1 -Archive .\brw-windows-x64.zip -ZipSha256 d5ddcd95ae06c7609d35f13f96aa3edb9d883015eaaa2f1968c2316325724c77 -BrwSha256 49328dce03efe66a953462536c1698debab21caefd7fc55370bf2456d7673ba3 -Work .\clean-result -ImageDescription '镜像来源、版本及安装方式' -PristineImage
```

返回 `clean-result/clean-windows.json`、`apply.json` 和 `apply.stderr`，并记录脚本退出码。预期 ZIP/EXE 摘要匹配，包列表为空，QuickJS 应用成功，采样的模块均来自 System32 并在许可清单内。`cleanHostVerified` 应为 true。程序会在新工作目录创建测试文件。

## macOS 共享核心与 C ABI

在已预置 Apple Clang、CMake、Ninja、Git 和 Python 3 的 macOS 主机，从交接包根目录运行。包内已包含 Git 历史和四份固定依赖。请使用新输出目录。

```sh
git clone --no-checkout candidate.bundle candidate
git -C candidate switch --detach 5e34c7819fadeea2a0eb373231e50941161b910c
mkdir -p candidate/.local/deps/sources
cp sources/* candidate/.local/deps/sources/
cd candidate
sh tests/release-acceptance/macos.sh 5e34c7819fadeea2a0eb373231e50941161b910c .local/mac-134
```

返回 `candidate/.local/mac-134/macos.log` 和 `blueprint/` 子目录。预期纯 C、C++23 经 C ABI 两种配置、三宿主共同的 Blueprint 及大小写敏感和不敏感 APFS 用例均通过。macOS 版本、工具版本和实际哈希会写入日志。

## Windows 经回环 SSH 到专用 WSL

使用有 Git、Python 3.12+ 和系统 OpenSSH 的 Windows 操作端。该操作端可以是开发机。请先准备本轮专用 WSL2，限制 SSH 监听为 127.0.0.1、使用一次性测试账号凭据、通过本地 WSL 控制台独立取得并核对主机 ED25519 公钥。测试账号应可用 unshare -Urn。完整的预置工具清单和信任文件格式在候选源码的 docs/ssh-build-acceptance.md 内。

```powershell
git clone --no-checkout .\candidate.bundle .\candidate
git -C .\candidate switch --detach 5e34c7819fadeea2a0eb373231e50941161b910c
New-Item -ItemType Directory -Force .\candidate\.local\deps\sources | Out-Null
Copy-Item .\sources\* .\candidate\.local\deps\sources\
Set-Location .\candidate
# 将下列变量设为可运行的解释器、目标端口、测试用户名以及已准备的两个文件路径。
& $python -B tests/ssh-acceptance/run.py --port $wslPort --user $wslUser --identity $testIdentity --known-hosts $trustedHosts --manifest-sha256 6fb5571a9c159a52f18e444e8784c9ff10f011ace54ab60f45e4b4dae05dd9c6 --evidence .local/ssh-134
```

返回 `transport.json`、`remote/`、主机公钥指纹的独立来源及清理记录。确认构建和 Linux ELF 均退出 0，传输前后摘要相同，断线结果为 unknown 且仅启动一次。取回记录后关闭回环监听、撤销临时凭据、停止专用 WSL，并验证原端口已拒绝连接。只交回脱敏证据。

## Windows 普通用户注册表

在独立普通账户的会话中打开 Windows PowerShell 5.1。账户应有权在自己的 HKCU/Software 下创建和清理测试专用子树。测试程序把操作限制在随机命名的专用子树中。保留终端返回及通过/失败状态。使用新工作目录。

~~~powershell
New-Item -ItemType Directory .\registry-result -ErrorAction Stop | Out-Null
& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File .\registry\brw-settings.ps1 -UserRegistry -Brw (Resolve-Path .\registry\brw_test_interrupt.exe) -Scratch (Resolve-Path .\registry-result) *> .\registry-result\hkcu.log
$LASTEXITCODE
~~~

预期退出 0；核对真实 REG_SZ、REG_DWORD 与 PATH 测试值、未授权写入的拒绝状态、三类恢复与保留用户后改值。返回 hkcu.log，记录普通令牌及临时子树已清理的事实。
